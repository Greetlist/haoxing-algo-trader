from enum import Enum, IntEnum


class VIntEnum(IntEnum):
    def __str__(self) -> str:
        return str(self.value)


class VStrEnum(str, Enum):
    def __str__(self) -> str:
        return str(self.value)


class Side(VIntEnum):
    BUY = 1
    SELL = -1


class OffSet(VIntEnum):
    OPEN = 0
    CLOSE = 1


class AlgoType(VStrEnum):
    TWAP = "HX_SMART_TWAP"
    VWAP = "HX_SMART_VWAP"


class FuturesAlgo(VStrEnum):
    CTA_TWAP = "HX_CTA_TWAP"


class T0Algo(VStrEnum):
    DIV = "T0_DivStrategy"


class QtyType(VIntEnum):
    DELTA = 1
    TARGET = 2


class TradeType(VIntEnum):
    NORMAL_BUY = 1
    NORMAL_SELL = 2
    COLLATERAL_BUY = 3       # 担保品买
    COLLATERAL_SELL = 4      # 担保品卖
    
    BUY_TO_COVER = 5         # 买券还券
    SELL_TO_SHORT = 6        # 融券卖出
    MARGIN_BUY = 7           # 融资买入
    SELL_TO_REPAY = 8        # 卖券还款


class OrderStatus(VIntEnum):
    INSERTING = 10
    INSERTED = 20
    INSERTFAILED = 25
    TRADED = 30
    TRADEDPARTIAL = 31
    CANCELLING = 40
    CANCELLFAILED = 45
    CANCELLED = 50
    REJECTED = 70


class TaskStatus(VIntEnum):
    ERROR = 0
    NEW = 1
    PART_FILLED = 2
    CANCELLING = 3
    REJECTED = 10
    FILLED = 11
    CANCELLED = 12
    EXPIRED = 13