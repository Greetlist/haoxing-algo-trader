from typing import Callable
import socketio
from HPI.utils import (
    enow,
    encrypt_params,
    decrypt_params
)
import time
from functools import partial


class WSClient:
    def __init__(self, target, user=None, cli_token=None, min_interval=5, version="v1") -> None:
        self.target = target
        self.cli_token = cli_token
        self.user = user
        self.min_interval = max(min_interval, 1)
        self._sio_client = socketio.Client()
        self.handlers = {}
        self.version = version
        self._emit_threads = {}
        self._stopped = True
        self.namespace = "/monitor"

    def regist(self, event: str, handler: Callable):
        self.handlers[event] = handler
    

    def _emit(self, event, data, namespace=None):
        data = {"msg": encrypt_params(data)}
        namespace = namespace or self.namespace
        self._sio_client.emit(event, data=data, namespace=namespace)

    def start(self):
        self._stopped = False
        # handle all response events
        sio_url = f"{self.target}"
        self._sio_client.connect(sio_url, namespaces=[self.namespace])
        self._emit("login", data=dict(token=self.cli_token))
        for topic in self.handlers:
            if topic == "account_info":
                event = f"{self.version}_account_info_records_response"
            elif topic == "positions":
                event = f"{self.version}_position_records_response"
            event = f"{self.version}_{topic}_response"
            handler = self.handlers[topic]
            self._sio_client.on(event, partial(self._handler, handler), self.namespace)
            self._emit_threads[topic] = self._sio_client.start_background_task(partial(self._query, topic))
        self._sio_client.wait()

    def _query(self, topic):
        event = f"{self.version}_{topic}"
        last_query_time = None
        next_query_time = enow() + self.min_interval * 1_000_000
        while not self._stopped:
            self._emit(event, data=dict(last_update_time=last_query_time, token=self.cli_token))
            last_query_time = enow()
            sleep_interval = (next_query_time - last_query_time) / 1_000_000
            time.sleep(sleep_interval)
            next_query_time = next_query_time + 1_000_000 * self.min_interval

    def _handler(self, handler, response):
        if "msg" in response:
            res = decrypt_params(response['msg'])
            print(res['total'])
            if res['list']:
                return handler(res['list'])
            else:
                return
        else:
            return handler(res)

    def stop(self):
        self._stopped = True
        self._sio_client.disconnect()
    
    def __del__(self):
        self.stop()

if __name__ == "__main__":
    ws = WSClient()
    ws.listen_to(["order", "task", "position", "accountinfo"])
    ws.start()