from HPI.constants import *
from HPI.task import (
    StockTask,
    StockT0Task,
    FuturesTask
)
import re   # don't remove it

def do_assertion(data, asserts, task_model):
    errs = []
    _local = {
        key: data.get(key) for key in task_model.__slots__
    }

    for assert_ in asserts:
        try:
            res = eval(assert_, globals(), _local)
        except Exception as ex:
            continue
        if not res:
            errs.append(f"Task: {data} not pass the assertion: {assert_}")
    return errs


STOCK_TASK_ASSERTS = [
    "account_id is not None",
    "algo_name is not None",
    "symbol is not None",
    "task_qty is not None",
    "start_time is not None",
    "end_time is not None",
    "trade_type is not None",
    "len(account_id) <= 32",
    "basket_id is None or len(basket_id) <= 50",
    "task_qty >= 0",
    "isinstance(task_qty, int)",
    f"qty_type in {[QtyType.DELTA.value, QtyType.TARGET.value]}",
    f"side in {[Side.BUY.value, Side.SELL.value]}",
    f"algo_name in {[AlgoType.TWAP.value, AlgoType.VWAP.value, 'SMART_TWAP', 'SMART_VWAP']}",  # temp support two type of algo name
    "isinstance(start_time, int)",
    "isinstance(end_time, int)",
    "start_time < 150000",
    "start_time > 0",
    "end_time > start_time",
    '''re.match("^(XSSC|XSEC|XSHG|XSHE)[0-9]{6}$", symbol)'''
]

STOCK_T0_TASK_ASSERTS = [
    "account_id is not None",
    "algo_name is not None",
    "symbol is not None",
    "buy_type is not None",
    "sell_type is not None",
    "start_time is not None",
    "end_time is not None",
    "max_vol is not None",
    "len(account_id) <= 32",
    "max_vol >= 0",
    f"algo_name in {[T0Algo.DIV.value]}",
    "isinstance(start_time, int)",
    "isinstance(end_time, int)",
    "start_time < 150000",
    "start_time > 0",
    "end_time > start_time",
    "end_time <= 150000",
    '''re.match("^(XSSC|XSEC|XSHG|XSHE)[0-9]{6}$", symbol)'''
]

FUTURE_TASK_ASSERTS = [
    "account_id is not None",
    "algo_name is not None",
    "symbol is not None",
    "task_qty is not None",
    "start_time is not None",
    "end_time is not None",
    "side is not None",
    "trade_type is not None",
    "len(account_id) <= 32",
    "basket_id is None or len(basket_id) <= 50",
    "task_qty >= 0",
    "isinstance(task_qty, int)",
    f"trade_type in {[TradeType.NORMAL_BUY.value, TradeType.NORMAL_SELL.value]}",
    f"qty_type in {[QtyType.DELTA.value, QtyType.TARGET.value]}",
    f"side in {[Side.BUY.value, Side.SELL.value]}",
    f"algo_name in {[FuturesAlgo.CTA_TWAP.value]}",
    "isinstance(start_time, int)",
    "isinstance(end_time, int)",
    '''re.match("^(CCFX|XSGE|XDCE|XZCE|XINE)[a-zA-Z]{1,2}[0-9]{3,4}$", symbol)'''
]

def check_stock_tasks(tasks):
    err_msgs = []
    for task in tasks:
        err_msg = do_assertion(task, STOCK_TASK_ASSERTS, StockTask)
        err_msgs.extend(err_msg)
    return err_msgs


def check_stock_t0_tasks(tasks):
    err_msgs = []
    for task in tasks:
        err_msg = do_assertion(task, STOCK_T0_TASK_ASSERTS, StockT0Task)
        err_msgs.extend(err_msg)
    return err_msgs


def check_futures_tasks(tasks):
    err_msgs = []
    for task in tasks:
        err_msg = do_assertion(task, FUTURE_TASK_ASSERTS, FuturesTask)
        err_msgs.extend(err_msg)
    return err_msgs


def check_order_events_params(params):
    """
    校验获取执行单事件参数
    :param params:
    :return:
    """
    errs = []
    limit = params["limit"]
    order_by = params["order_by"]
    if limit is not False and limit is not None and not (isinstance(limit, int) and limit > 0):
        errs.append("limit: type error")
    if order_by is not None and order_by.lstrip('-') not in ['last_update_time', 'date', 'account_id', 'wid', 'volume',
                                                             'traded_volume', 'price', 'traded_price', 'order_status',
                                                             'inserted_time', 'side', 'cancelled_volume']:
        errs.append("order_by: not in the choices")
    return errs


def check_get_positions_params(params):
    """
    校验获取持仓请求参数
    :param params:
    :return:
    """
    errs = []
    limit = params["limit"]
    order_by = params["order_by"]
    if limit is not False and limit is not None and not (isinstance(limit, int) and limit > 0):
        errs.append("limit: type error")
    if order_by is not None and order_by.lstrip('-') not in ['last_update_time', 'date', 'account_id', 'wid',
                                                             'current_long_pos', 'td_long_pos', 'td_short_pos',
                                                             'yd_long_pos', 'yd_short_pos']:
        errs.append("order_by: not in the choices")

    return errs


def check_get_init_cash_params(params):
    """
    校验获取每日初始资金参数
    :param params:
    :return:
    """
    errs = []
    limit = params["limit"]
    order_by = params["order_by"]
    if limit is not False and limit is not None and not (isinstance(limit, int) and limit > 0):
        errs.append("limit: type error")
    if order_by is not None and order_by.lstrip('-') not in ['last_update_time', 'date', 'account_id', 'available']:
        errs.append("order_by: not in the choices")
    return errs


def check_update_password_params(params):
    """
    校验修改密码参数
    :param params:
    :return:
    """
    errs = []
    old_password = params["old_password"]
    new_password = params["new_password"]
    if not old_password:
        errs.append("old_password: must has value")
    else:
        if not isinstance(old_password, str):
            errs.append("old_password: type error")
    if not new_password:
        errs.append("new_password: must has value")
    else:
        if not isinstance(new_password, str):
            errs.append("new_password: type error")
    return errs


def check_activate_account_params(params):
    """
    校验激活交易账号参数
    :param params:
    :return:
    """
    errs = []
    account = params["account"]
    password = params["password"]
    if not account:
        errs.append("account: must has value")
    else:
        if not isinstance(account, str):
            errs.append("account: type error")
    if not password:
        errs.append("password: must has value")
    else:
        if not isinstance(password, str):
            errs.append("password: type error")
    return errs





