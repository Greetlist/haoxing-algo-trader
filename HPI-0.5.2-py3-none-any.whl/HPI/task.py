from typing import Union
import json

from HPI.constants import (
    TradeType,
    AlgoType,
    QtyType,
    T0Algo,
    Side,
    OffSet
)
from HPI.utils import now


class Task:
    __slots__ = []
        
    def to_dict(self):
        res = {}
        for field in self.__slots__:
            value = getattr(self, field)
            if value is not None:
                res[field] = value
        return res
    
    def __repr__(self) -> str:
        s = "Task("
        vs = []
        for field in self.__slots__:
            value = getattr(self, field)
            if value is not None:
                vs.append(f"{field}={value}")
        return s + ",".join(vs) + ")"

    def __getitem__(self, key):
        return getattr(self, key)

    def get(self, key):
        return self[key]

class StockTask(Task):
    __slots__ = [
        "account_id",
        "start_time",
        "end_time",
        "algo_name",
        "symbol",
        "qty_type",
        "task_qty",
        "trade_type",
        "basket_id",
        "limit_up_down_trading",
        "expiration_trading",
        "algo_params"
    ]
    def __init__(self,
        symbol: str,
        task_qty: int,
        trade_type: TradeType,
        qty_type: QtyType=QtyType.DELTA,
        start_time: int=None,
        end_time: int=None,
        algo_name: AlgoType=None,
        account_id: str=None,
        basket_id: str=None,
        limit_up_down_trading: bool=None, 
        algo_params: dict=None,
        **kwargs    # handle extra input params
    ) -> None:
        """
        Struct of task
        """
        self.account_id = account_id
        self.start_time = start_time
        self.end_time = end_time
        self.algo_name = algo_name
        self.symbol = symbol
        self.qty_type = qty_type
        self.task_qty = task_qty
        self.trade_type = trade_type
        self.limit_up_down_trading = limit_up_down_trading
        self.expiration_trading = None
        self.algo_params = algo_params
        self.basket_id = basket_id


class StockT0Task(Task):
    __slots__ = [
        "account_id",
        "start_time",
        "end_time",
        "algo_name",
        "symbol",
        "buy_type",
        "sell_type",
        "max_vol",
        "expiration_trading",
        "t0_params",
        "limit_up_down_trading"
    ]
    """
    Struct of T0 task
    """
    def __init__(self,         
        symbol: str,
        max_vol: int,
        buy_type: TradeType,
        sell_type: TradeType,
        start_time: int=None,
        end_time: int=None,
        algo_name: Union[T0Algo, str]=None,
        account_id: str=None,
        limit_up_down_trading: bool=None,
        t0_params: dict=None,
        **kwargs
    ) -> None:
        self.account_id = account_id
        self.max_vol = max_vol
        self.start_time = start_time
        self.end_time = end_time
        self.algo_name = algo_name
        self.symbol = symbol
        self.buy_type = buy_type
        self.sell_type = sell_type
        self.limit_up_down_trading = limit_up_down_trading
        self.expiration_trading = None
        self.t0_params = t0_params

class FuturesTask(Task):
    __slots__ = [
        "account_id",
        "start_time",
        "end_time",
        "algo_name",
        "symbol",
        "qty_type",
        "task_qty",
        "trade_type",
        "basket_id",
        "limit_up_down_trading",
        "expiration_trading",
        "offset_flag",
        "extend",
        "algo_params"
    ]
    def __init__(self,
        symbol: str,
        task_qty: int,
        trade_type: TradeType,
        qty_type: QtyType=QtyType.DELTA,
        start_time: int=None,
        end_time: int=None,
        algo_name: AlgoType=None,
        account_id: str=None,
        basket_id: str=None,
        limit_up_down_trading: bool=None, 
        offset_flag: OffSet=None,
        algo_params: dict=None,
        **kwargs
    ) -> None:
        self.account_id = account_id
        self.start_time = start_time
        self.end_time = end_time
        self.algo_name = algo_name
        self.symbol = symbol
        self.qty_type = qty_type
        self.task_qty = task_qty
        if self.qty_type == QtyType.DELTA:
            self.trade_type = trade_type
        else:
            self.trade_type = trade_type.NORMAL_BUY   # force use buy side for Target qty type
        self.limit_up_down_trading = limit_up_down_trading
        self.expiration_trading = None
        self.algo_params = algo_params
        self.basket_id = basket_id
        self.offset_flag = offset_flag
        self.extend = kwargs

    def to_dict(self):
        res = {}
        for field in self.__slots__:
            value = getattr(self, field)
            if value is not None:
                if field == "extend":
                    res[field] = json.dumps(value)
                else:
                    res[field] = value
        return res
    
class DirectFuturesTask(FuturesTask):
    def __init__(self, 
        account_id: str,
        symbol: str, 
        task_qty: int, 
        side: Side, 
        algo_name: AlgoType, 
        limit_up_down_trading: bool = None, 
        offset_flag: OffSet = None, 
        algo_params: dict = None,
        **kwargs
    ) -> None:
        super().__init__(symbol, task_qty, qty_type=QtyType.DELTA, 
            side=side, algo_name=algo_name, account_id=account_id, 
            limit_up_down_trading=limit_up_down_trading, 
            offset_flag=offset_flag, algo_params=algo_params,**kwargs
        )

    def to_dict(self):
        res = {}
        self.start_time = int(now().strftime("%H%M%S")) # force using nowtime as start_time, end_time
        self.end_time = self.start_time
        for field in self.__slots__:
            value = getattr(self, field)
            if value is not None:
                if field == "extend":
                    res[field] = json.dumps(value)
                else:
                    res[field] = value
        return res
    