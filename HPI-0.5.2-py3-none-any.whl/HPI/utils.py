import dateutil.tz as tz
import datetime
from HPI.config import Config
import json
import base64
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad


def now():
    localtz = tz.gettz(Config.timezone)
    return datetime.datetime.now(tz=localtz)


def enow():
    return int(now().timestamp() * 1e6)

MIC_MAPPING = {
    "XSHG": ".SH",
    "XSHE": ".SZ"
}

def sidtowid(sid):
    return sid[4:] + MIC_MAPPING[sid[:4]]
    

AES_KEY = b"y29m33frsmbr6to8vpgde9edkw3g8ob3"
AES_IV = b"XZJ2030405060708"


def decrypt_params(text, key=AES_KEY, iv=AES_IV):
    """
    api 解密
    :param poster:
    :return:
    """
    return json.loads(decrypt_string(text, key=key, iv=iv))


def encrypt_params(data, key=AES_KEY, iv=AES_IV):
    """
    api 加密
    :param data:
    :return:
    """
    return encrypt_string(json.dumps(data), key=key, iv=iv)


def encrypt_string(string, key=AES_KEY, iv=AES_IV):
    cipher = AES.new(key, AES.MODE_CBC, iv)
    ciphertext = cipher.encrypt(pad(string.encode("utf-8"), AES.block_size))
    return base64.b64encode(ciphertext).decode("utf-8")
    # return ciphertext.hex()


def decrypt_string(string, key=AES_KEY, iv=AES_IV):
    decode_str = base64.b64decode(string.encode("utf-8"))
    cipher = AES.new(key, AES.MODE_CBC, iv)
    return unpad(cipher.decrypt(decode_str), AES.block_size).decode("utf-8")


def olist(v):
    if isinstance(v, (int, str, float)):
        return [v]
    elif isinstance(v, list):
        return v
    else:
        return v

if __name__ == "__main__":
    # print(AES_KEY.hex())
    # print(AES_IV.hex())
    jss = {"msg":"XVjO9Y11mqD3lzg9jxi26nF+IVLpzp0WxSqd3/MU+8JJ5W47N85Lo3oNeKotrwCy1tPm6dpgcqNBrNZJhiQWMKLYfDS37Ybmm3JO0EKqgtwKD3bQ/vt+EAW7RbLvV5jGDYVnT2X8gUO5r3FzV3IwbTqXP/8nNeVugmuXdHpZSs4BQrxTiZvp5hgX0QfpKr27xFZSpnOQeYkOY+4LBVYlK1YE4vj/M/6nN1h7f+CyG87Mq9XO5EPBmKg2w8aY1RAmJHv2pJfaa4Kv6r7M3GmD7RWruk+fM1wHVU2iJ3XxU2X0T1gf7idozc+sgq2bF0870XYD9n0EtWd7CXttHgAo4f5By4rmPKMnsI0/HndNPkDpJlgcQqbLKj37FPxNfPsuDqAN5ov7T9kRbqNX7xFwYLBbEPtDj6o9SWzxJyPg5SxruGbu5qVl4dfWwsTYFQ/ilT3l45uEYpeT97Upv7teTmqvVEnppg1meo63PMCm5g65V/mWcqilWrfg/F0nTLpm+xkEOynzTLjzx9tiEzApPhTPIQkOkDQpmViloz9Rb5SpEHe4+qJIwlTwZQ4sLYdAwZuhaXrolFenrvrWVrQnnw5hTYNIBty0x1ehHQ+pr8c1fYdjjlHSt2kBHEwu7lBtwg2DThnoGEwIvORvRpphR/XaNFunXhNSWOSJhgnRAn1xek+JfxofamxYtdZu1ctBBRHCNf0BFticJdCwsqavvYqYi6bjZV3TOSM+oKXYFqhn1SQIPko5P+p6QGzV02tvPggrVnfzDiqiMX9zp6ye1WPmDClib5gO0ib5f6/0Tg8K6FjABz/bLYGseAnXikEkowRS/mNnyZpbRClG4FldyAXgETbJBB45HC+Umaye9M7+hP8JM9lYQ37Sut90AZomfvN15gTBmQ4wvZEwpckbjL0ehCA7NxPfFstuDFXOZkd8CYwIYhksdWoakcwBCG8KmChLDfOAkeukR8dtGN6OEpcEQBfOrAOaYlx1KNpN4la61BmfPm0p9Fk9E/v79dJ+Ag1vz52F8DRH9hk1WNy1v0mOgHZQiT5uQLXC7gxeR7dBdDuPqRyYMurTDqkzomKZI0qnE6i0Bs6iy7SM2fttRtnVeKAXrY8KoGruXx5/qXFDrWltJ+TtmJmXibcH9WaX54DMBtLt56ZiLscBGTLGqtG229bT0dXhlStnb6U/aXWFfavu7eHoc+Cek8vnyNxMBM6PlZsGQ4imYnSSW0PtK1EvjktOOKjQ92niJtHm3h+93TjZS4tpOpHZi/GxhiINCFrm6nSIIntkvDddJQOXfS+FImSybtpimtrX6IWULqoh2/oJlt/zSf6B28qiYkPMJy2em8FNvs2oK8lLNjbIsLrfadD3yrwilrc+3C4RPR4="}
    # print(encrypt_string(jss))
    print(decrypt_string(jss['msg']))
    # encrypted_data = "hpel8BolK+s1zAOWyj9Jmmmm3datnmJj2Zl9+EezpYAHSYsFHOItMVvNEpxJJ+YskYlKGioZrCygrZO5MuiVGLi728qvMQyjODJn58vjj4y42zQ3s6Ct/C+kQqxpFsAZl47AIVfRN0MjJf/KOp2fdwJ56NjR91keNSPn5mp10DzlVgUuKHBAc6FB+pQTza2q5jZbQ9clpx2uTheBHIjLguvfV7/s4RUuTVohh60s8Re8MqYdnSUvgQ1zb5y2Z+OLTh58OzmhE6dGaOd5tmMBpKK88ix9Rv8NA9kbnQYrJvVDakgUIgKFuZOhZISZvH6zh9/ZSL7Mx25Uk0tSCJ5SYkVe6zBk7xq+moBLfPTlauM="
    # print(decrypt_string(encrypted_data))
    # res_data = "yS0J0O4UzCrpTN98Ewfc/UNB4vGaocjerNL9aY3hNAkICHc8voEISiEvGF6KD7V7pxrooaZxrIu0sWQ/RRqvXFSjHwTkcndxgsyLdX0PwqNkze1cRslLWvw+ZdfLNeetcmFkZV90eXBx"
    # print(decrypt_string(res_data))
    
    