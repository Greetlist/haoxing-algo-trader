class ValidationError(Exception):
    def __init__(self, err_msgs, *args: object) -> None:
        msg = "\n" + "\n".join(err_msgs)
        super().__init__(msg)

class ResponseError(Exception):
    def __init__(self, error_code, msg, header=None, *args: object) -> None:
        self.error_code = error_code
        self.err_msg = msg
        self.header = header
        err = f"ERROR_CODE {self.error_code}, MSG {self.err_msg}"
        if self.header:
            err += f", SEQ {self.header['seq']}"
        super().__init__(err)

class TimeoutWarning(Exception):
    def __init__(self, header=None, *args: object) -> None:
        self.header = header
        err = f"Network timeout, but the task should be created. Please do not re-send the tasks!"
        if self.header:
            err += f" SEQ {self.header['seq']}"
        super().__init__(err)