class Config:
    timezone = "Asia/Shanghai"

    @classmethod
    def load_config(cls, config):
        for k in config:
            if hasattr(cls, k):
                setattr(cls, k, config[k])
