from typing import List, Union
import httpx
from psutil import net_if_addrs
from HPI.constants import AlgoType, T0Algo
from HPI.task import (
    Task,
    StockT0Task
)
from HPI.utils import (
    decrypt_params, 
    encrypt_params, 
    now, 
    olist,
    sidtowid
)
from HPI.validate import (
    check_stock_tasks,
    check_stock_t0_tasks,
    check_get_positions_params,
    check_order_events_params,
    check_get_init_cash_params,
    check_futures_tasks,
    check_update_password_params,
    check_activate_account_params
)

from HPI.exceptions import (
    ResponseError,
    TimeoutWarning,
    ValidationError
)
from httpx import ReadTimeout


def get_mac_address():
    res = []
    for v in net_if_addrs().values():
        for item in v:
            if item.family.name in ['AF_LINK', 'AF_PACKET']:
                res.append(item.address)
    return ",".join(res)


class HttpClient:
    def __init__(
        self, 
        target: str, 
        user: str=None, 
        password: str=None,
        cli_token: str=None,
        *,
        timeout: int=10,
        direct: bool=False, 
        validate: bool=True
    ) -> None:
        """
        Create a Ginkgo Http Client
        Use http2 protocol
        
        Args:
            target (str): target url
            user (str): the cli user
            password (str): the password for authentication
            timeout (int): the client timeout time, default to 10
            direct (bool): connect with backend without nginx, just for sending tasks; default to False
            validate (bool): validate the input tasks;default to True
        """
        self.target = target
        self.cli_token = cli_token
        self.user = user
        self.password = password
        self.timeout = timeout
        self.max_batch = 10000
        self.direct = direct
        self.validate = validate
        self.headers = {"source": "SDK", "Mac": get_mac_address()}
        self.account_map = {}
        if not self.direct:
            self.login()
            self.account_map = {account["account_id"]: account["account"] for account in self.get_tradeaccount()}

    def create_tasks(
        self, 
        tasks: Union[List[Task], List[dict]], 
        seq: int=None,
        *, 
        version: str="v1"
    ):    # may need to update the latest version somewhere
        """
        create tasks
        Args:
            tasks (Union[List[Task], List[dict]]): The list of tasks. Can be task lists or dict lists. No more than 4000.
            seq: The seq of request. Default will be the timestamp.
            version (str, optional): Defaults to "v1". Only support v1 now.

        Returns:
            res: The server response, examples:
            {
                "header" : $header,
                "error_code": 0, //<0:Error, =0:Success, >0:Warning 
                "message": "success",
                "datas": [
                    {"account_id":"12345", "index":1, "client_task_id": 12345, "error_code":0, "message": "success"},
                    {"account_id":"12346", "index":2, "client_task_id": -1, "error_code":-100, "message": "system error"}
                }
            }
        """
        if len(tasks) > self.max_batch:
            raise ValueError(f"Only support to at most {self.max_batch} tasks at one time.")
        header = self._make_header(seq=seq)
        tasks = self._make_tasks(tasks)
        if self.validate:
            err_tasks = check_stock_tasks(tasks)
            if err_tasks:
                raise ValidationError(err_tasks)

        if self.direct:
            h1, h2 = False, True
        else:
            h1, h2 = True, False
        res = self.request("post", url=f"{self.target}/apis/algo/{version}/create-task", raw_body=dict(header=header, tasks=tasks), h1=h1, h2=h2)
        if 'datas' not in res:
            # handle datas not in res error
            raise ResponseError(-1, res, header)
        for r in res['datas']:
            account_num = r['account_id'].split("_")[-1]
            account_id = "_".join(r['account_id'].split("_")[:-1])
            if account_id in self.account_map:
                if self.account_map[account_id] == account_num:
                    r['account_id'] = account_id
        return res

    def create_t0_tasks(
        self, 
        tasks=Union[List[StockT0Task], List[dict]],
        seq: int=None,
        avail_amount: float = None,
        *,
        version: str="v1"
    ):
        if len(tasks) > self.max_batch:
            raise ValueError(f"Only support to at most {self.max_batch} tasks at one time.")
        header = self._make_header(seq=seq)
        tasks = self._make_tasks(tasks)
        if self.validate:
            err_tasks = check_stock_t0_tasks(tasks)
            if err_tasks:
                raise ValidationError(err_tasks)
        if self.direct:
            h1, h2 = False, True
        else:
            h1, h2 = True, False
        return self.request("post", url=f"{self.target}/apis/algo/{version}/create-t0task", raw_body=dict(header=header, tasks=tasks, avail_amount=avail_amount), h1=h1, h2=h2)

    def create_futures_task(self, task: Task, seq: int=None, *, version="v1"):
        header = self._make_header(seq=seq)
        tasks = self._make_tasks([task])
        if self.validate:
            err_tasks = check_futures_tasks(tasks)
            if err_tasks:
                raise ValidationError(err_tasks)
        if self.direct:
            h1, h2 = False, True
        else:
            h1, h2 = True, False
        return self.request("post", url=f"{self.target}/apis/algo/{version}/create-futures-task", raw_body=dict(header=header, tasks=tasks), h1=h1, h2=h2)

    def create_batch_tasks(self, 
        tasks: Union[List[Task], List[dict]], 
        account_id: str,
        start_time: int, 
        end_time: int, 
        algo_name: AlgoType,
        seq: int=None,
        # limit_up_down_trading: bool=None, TODO: add after backend support
        # expiration_trading: bool=None,
        *, 
        version="v1"
    ):
        """
        Create Batch Tasks
        All tasks share the same start_time, end_time, account_id and algo_name
        Args:
            tasks (Union[List[Task], List[dict]]): The list of tasks. Can be task lists or dict lists. No more than 4000.
            account_id (str): The id of account.
            start_time (int): The HHMMSS style int time.
            end_time (int): The HHMMSS style int time.
            algo_name (AlgoType): The algo name of all tasks.
            seq(int): The seq of request. Default will be the timestamp.
            version (str, optional): Defaults to "v1". Only support v1 now.

        Returns:
            res: The server response, examples:
            {
                "header" : $header,
                "error_code": 0, //<0:Error, =0:Success, >0:Warning 
                "message": "success",
                "datas": [
                    {"account_id":"12345", "index":1, "client_task_id": 12345, "error_code":0, "message": "success"},
                    {"account_id":"12346", "index":2, "client_task_id": -1, "error_code":-100, "message": "system error"}
                }
            }
            }
        """
        if len(tasks) > self.max_batch:
            raise ValueError(f"Only support to at most {self.max_batch} tasks at one time.")
        header = self._make_header(seq=seq)
        tasks = self._make_tasks(
            tasks, 
            start_time=start_time, 
            end_time=end_time, 
            account_id=account_id, 
            algo_name=algo_name, 
            # limit_up_down_trading=limit_up_down_trading,
            # expiration_trading=expiration_trading
        )
        if self.validate:
            err_tasks = check_stock_tasks(tasks)
            if err_tasks:
                raise ValidationError(err_tasks)
        if self.direct:
            h1, h2 = False, True
        else:
            h1, h2 = True, False
        res = self.request("post", url=f"{self.target}/apis/algo/{version}/create-task", raw_body=dict(header=header, tasks=tasks), h1=h1, h2=h2)
        if 'datas' not in res:
            # handle datas not in res error
            raise ResponseError(-1, res, header)
        for r in res['datas']:
            account_num = r['account_id'].split("_")[-1]
            account_id = "_".join(r['account_id'].split("_")[:-1])
            if account_id in self.account_map:
                if self.account_map[account_id] == account_num:
                    r['account_id'] = account_id
        return res

    def create_t0_batch_tasks(self,
          tasks: Union[List[Task], List[dict]],
          account_id: str,
          start_time: int,
          end_time: int,
          algo_name: T0Algo,
          avail_amount: float = None,
          seq: int = None,
          *,
          version="v1"
          ):
        """
        :param tasks: (Union[List[Task], List[dict]]): The list of tasks. Can be task lists or dict lists
        :param account_id: The id of account
        :param start_time: The HHMMSS style int time.
        :param end_time: The HHMMSS style int time.
        :param algo_name: The algo name of all tasks.
        :param avail_amount: the avail_amount, not required
        :param seq: The seq of request. Default will be the timestamp.
        :param version: Defaults to "v1"
        :return:
            {
                "header" : $header,
                "error_code": 0, //<0:Error, =0:Success, >0:Warning
                "message": "success",
                "datas": [
                    {"account_id":"12345", "index":1, "client_task_id": 12345, "error_code":0, "message": "success"},
                    {"account_id":"12346", "index":2, "client_task_id": -1, "error_code":-100, "message": "system error"}
                }
            }
            }
        """
        if len(tasks) > self.max_batch:
            raise ValueError(f"Only support to at most {self.max_batch} tasks at one time.")
        header = self._make_header(seq=seq)
        tasks = self._make_tasks(
            tasks,
            start_time=start_time,
            end_time=end_time,
            account_id=account_id,
            algo_name=algo_name
        )
        if self.validate:
            err_tasks = check_stock_t0_tasks(tasks)
            if err_tasks:
                raise ValidationError(err_tasks)
        if self.direct:
            h1, h2 = False, True
        else:
            h1, h2 = True, False
        res = self.request("post", url=f"{self.target}/apis/algo/{version}/create-t0task",
                           raw_body=dict(header=header, tasks=tasks, avail_amount=avail_amount), h1=h1, h2=h2)
        return res

    def cancel_tasks(
            self,
            tasks=List[dict],
            seq: int = None,
            *,
            version: str = "v1"
    ):
        """
        :param tasks: [{"client_task_id": int, "account_id": str}, {}]
        :param seq: The seq of request. Default will be the timestamp.
        :param version: Defaults to "v1"
        :return: {
                "header":$header,
                "error_code":0,
                "message":"",
                "datas":[{"client_task_id": 123456, "error_code":0, "message":""}]
            }
        """
        header = self._make_header(seq=seq)
        ordered_account_id = list(set([task["account_id"] for task in tasks]))
        
        if self.account_map:
            # won't check accountid if no account_map
            error_account_id = [account_id for account_id in ordered_account_id if
                                account_id not in self.account_map.keys()]
            if error_account_id:
                raise ValueError("account_id: %s error" % ",".join(error_account_id))

        for idx, task in enumerate(tasks):
            if task['account_id'] in self.account_map:
                task["account_id"] = task["account_id"] + "_" + self.account_map[task["account_id"]]
            tasks[idx] = task
        if self.direct:
            h1, h2 = False, True
        else:
            h1, h2 = True, False
        res = self.request("post", url=f"{self.target}/apis/algo/{version}/cancel-task",
                           raw_body=dict(header=header, tasks=tasks), h1=h1, h2=h2)
        return res

    def _merge_res(self, all_res, header=None):
        final_res = dict(header=header, datas=[])
        for res in all_res:
            final_res['datas'].extend(res['datas'])
            # final_res['error_code'] = res['error_code']
            # final_res['msg'] = res['msg']
        return final_res

    def request(self, method, url, raw_body, h1=True, h2=False):
        if "header" not in raw_body:
            raw_body["header"] = self._make_header()
        body = encrypt_params(raw_body)
        headers = self.headers
        if self.cli_token:
            headers.update({"X-Token": self.cli_token})
        with httpx.Client(http1=h1, http2=h2) as client:
            try:
                response = client.request(method, url, json={"msg": body}, timeout=self.timeout, headers=headers)
            except ReadTimeout as ex:
                # wrap the exception
                raise TimeoutWarning(header=raw_body['header'])
        try:
            encrypted_res = response.json()
        except Exception:
            if response.status_code >= 300:
                raise ResponseError(response.status_code, response.text)
            else:
                return response.text

        if "msg" in encrypted_res:
            res = decrypt_params(encrypted_res['msg'])
        else:
            res = encrypted_res
        if 'error_code' in res:
            if res['error_code'] < 0:
                raise ResponseError(res['error_code'], res['message'], header=res['header'])
            elif 400 <= res['error_code'] <= 500 or 200 <= res["error_code"] < 300:
                raise ResponseError(res['error_code'], res['message'], header=raw_body["header"])
        return res

    def login(self, user=None, password=None, *, version="v1"):
        if self.password:
            url = f"{self.target}/apis/user/{version}/sdk-login-by-pwd"
            user = user or self.user
            password = password or self.password
            res = self.request("post", url, raw_body=dict(account=user, password=password), h2=False)
            self.cli_token = res["data"]["token"]
            return res["data"]

        elif not self.password and self.cli_token:
            url = f"{self.target}/apis/user/{version}/sdk-login"
            user = user or self.user
            token = self.cli_token
            res = self.request("post", url, raw_body=dict(name=user, token=token), h2=False)
            return res

    def update_password(self, old_password=None, new_password=None, *, version="v1"):
        err_params = check_update_password_params(locals())
        if err_params:
            raise ValidationError(err_params)
        url = f"{self.target}/apis/user/{version}/update-password"
        res = self.request("post", url, raw_body=dict(old_password=old_password, new_password=new_password,
                                                      new_password_confirm=new_password), h2=False)
        return res

    def get_tradeaccount(self, *, version="v1"):
        url = f"{self.target}/apis/user/{version}/get-tradeaccount"
        res = self.request("post", url, raw_body=dict(h2=False))
        return res["data"]

    def activate_account(self, account=None, password=None, *, version="v1"):
        err_params = check_activate_account_params(locals())
        if err_params:
            raise ValidationError(err_params)
        url = f"{self.target}/apis/user/{version}/activate-tradeaccount"
        res = self.request("post", url, raw_body=dict(account=account, password=password), h2=False)
        return res

    def get_tasks(self, 
        account_id: Union[str, List[str]]=None, 
        task_status: Union[str, List[str]]=None,
        trade_type: Union[str, List[str]]=None,
        symbol: str=None,
        algo: Union[str, List[str]]=None,
        basket_id: str=None,
        batch_id: str=None,
        start_time: int=None,
        end_time: int=None,
        after: int=None,
        limit: int=100,
        order_by: str=None,
        page: int=1,
        *, 
        version="v1"
    ):
        if symbol:
            wid = sidtowid(symbol)
        else:
            wid = None
        url = f"{self.target}/apis/data/{version}/tasks"
        res = self.request("post", url, raw_body=dict(
            page=page,
            page_size=limit,
            order_by=order_by,
            account_id=olist(account_id),
            trade_type=olist(trade_type),
            task_status=olist(task_status),
            wid=wid,
            algo=olist(algo),
            basket_id=basket_id,
            batch_id=batch_id,
            start_time=start_time,
            end_time=end_time,
            last_update_time=after
        ))
        return self._wrap_query_res(res)

    def get_orders(self, 
        account_id: Union[str, List[str]]=None,
        order_status: Union[str, List[str]]=None,
        trade_type: Union[str, List[str]]=None,
        symbol: str=None,
        algo: Union[str, List[str]]=None,
        basket_id: str=None,
        start_time: int=None,
        end_time: int=None,
        after: int=None,
        limit: int=100,
        page: int=1,
        order_by=None,
        *, 
        version="v1"
    ):
        if symbol:
            wid = sidtowid(symbol)
        else:
            wid = None
        url = f"{self.target}/apis/data/{version}/orders"
        res = self.request("post", url, raw_body=dict(
            page=page,
            page_size=limit,
            order_by=order_by,
            account_id=olist(account_id),
            trade_type=olist(trade_type),
            order_status=olist(order_status),
            wid=wid,
            algo=olist(algo),
            basket_id=basket_id,
            start_time=start_time,
            end_time=end_time,
            last_update_time=after
        ))
        return self._wrap_query_res(res)

    def get_orderevents(self,
        account_id: Union[str, List[str]] = None,
        symbol: Union[str, List[str]] = None,
        order_by: str = None,
        limit: int = 100,
        page: int = 1,
        after: int = None,
        before: int = None,
        *,
        version="v1"
    ):
        err_params = check_order_events_params(locals())
        if err_params:
            raise ValidationError(err_params)
        if symbol:
            wid = sidtowid(symbol)
        else:
            wid = None
        url = f"{self.target}/apis/data/{version}/order-events"
        res = self.request("post", url=url, raw_body=dict(
            wid=wid,
            page=page,
            page_size=limit,
            order_by=order_by,
            account_id=olist(account_id),
            start_timestamp=after,
            end_timestamp=before
        ))
        return self._wrap_query_res(res)

    def get_positions(self, 
        account_id: Union[str, List[str]]=None, 
        symbol: Union[str, List[str]]=None,
        order_by: str=None,
        limit: int = 100,
        page: int = 1,
        after: int=None,
        before: int = None,
        *,
        version="v1"
    ):
        err_params = check_get_positions_params(locals())
        if err_params:
            raise ValidationError(err_params)
        if symbol:
            wid = sidtowid(symbol)
        else:
            wid = None
        url = f"{self.target}/apis/data/{version}/positions"
        res = self.request("post", url=url, raw_body=dict(
            wid=wid,
            page=page,
            page_size=limit,
            order_by=order_by,
            account_id=olist(account_id),
            start_timestamp=after,
            end_timestamp=before
        ))
        return self._wrap_query_res(res)

    def get_account_info(self, 
        account_id=None, 
        order_by=None,
        page: int=1,
        limit: int=100,
        *,
        version="v1"
    ):
        account_id=olist(account_id)
        url = f"{self.target}/apis/data/{version}/account_info"
        res = self.request("post", url=url, raw_body=dict(
            page=page,
            page_size=len(account_id) if account_id else limit,
            order_by=order_by
        ))
        return self._wrap_query_res(res)

    def get_init_cash(self, account_id: Union[str, List[str]] = None, order_by: str = None,
                      limit: Union[int, bool] = None, *, version="v1"):
        err_params = check_get_init_cash_params(locals())
        if err_params:
            raise ValidationError(err_params)
        account_id = olist(account_id)
        url = f"{self.target}/apis/data/{version}/account_info"
        res = self.request("post", url=url, raw_body=dict(
            account_id=account_id,
            page=1,
            page_size=None,
            order_by=order_by,
            daily_init_cash=True
        ))
        cash_list = []
        for cash in res["data"]["list"]:
            cash_list.append({key: value for key, value in cash.items() if
                              key in ["account_id", "date", "last_update_time", "available"]})
        return cash_list

    def get_cash(self, account_id: Union[str, List[str]] = None, order_by: str = None,
                      limit: Union[int, bool] = None, *, version="v1"):
        err_params = check_get_init_cash_params(locals())
        if err_params:
            raise ValidationError(err_params)
        account_id = olist(account_id)
        url = f"{self.target}/apis/data/{version}/account_info"
        res = self.request("post", url=url, raw_body=dict(
            account_id=account_id,
            page=1,
            page_size=None,
            order_by=order_by,
        ))
        cash_list = []
        for cash in res["data"]["list"]:
            cash_list.append({key: value for key, value in cash.items() if
                              key in ["account_id", "date", "last_update_time", "available"]})
        return cash_list

    def _wrap_query_res(self, res):
        wrapped_res = {}
        if 'list' in res['data']:
            wrapped_res['data'] = res['data']['list']
        if 'total' in res['data']:
            wrapped_res['total'] = res['data']['total']
        return wrapped_res

    def _make_header(self, seq=None):
        ts = int(now().timestamp() * 1e3)   # ms
        seq = seq or ts
        return dict(timestamp=ts, seq=seq)

    def _make_tasks(self, tasks: Union[List[Task], List[dict]], **kwargs):
        body = []
        for idx, task in enumerate(tasks):
            if isinstance(task, Task):
                task_node = task.to_dict()
            else:
                task_node = dict(**task)
            task_node['index'] = idx
            if kwargs:
                task_node.update(kwargs)
            body.append(task_node)
        ordered_account_id = list(set([task["account_id"] for task in body]))
        if self.account_map:
            error_account_id = [account_id for account_id in ordered_account_id if account_id not in self.account_map.keys()]
            if error_account_id:
                raise ValueError("account_id: %s error" % ",".join(error_account_id))
            
        for idx, task in enumerate(body):
            if task['account_id'] in self.account_map:
                task["account_id"] = task["account_id"] + "_" + self.account_map[task["account_id"]]
            body[idx] = task
        return body
